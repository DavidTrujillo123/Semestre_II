/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paquete1;

/**
 *
 * @author Asus
 */
public class Hora {
    private int hora;
    private int min;
    private int seg;
    
    public Hora(int hora, int min, int seg){
        this.hora = hora;
        this.min = min;
        this.seg = seg;
        
        if(hora < 0 || hora > 23){
            hora = 1;
        }
        if(min<0 || min > 59){
            min = 1;
        }
        if (seg < 0 || seg > 59){
            seg = 1;
        }
    }
    public Hora(){
        this.hora = 0;
        this.min = 0;
        this.seg = 0;
    }
    public int TotalSegundos(){
        int segTotales = 0;
        segTotales += this.hora * 3600;
        segTotales += this.min * 60;
        segTotales += this.seg;
        return segTotales;
    }
    public Hora DesdeSegundos(int seg){
        int hora, min;
        hora = 0;
        min = 0;
        if(seg >= 3600){
            hora =seg / 3600;
            seg -= hora*3600;
            if(seg >= 60){
                min = seg/60;
                seg -= min*60;
            }
        }
        return new Hora(hora, min, seg);
    }
    public void IncrementarSeg(){
        if(seg == 59){
            seg = 0;
            if(min == 59){
                min = 0;
                if(hora == 23){
                    hora = 0;
                }
                else hora++;
            }else min++;
            
        }else seg++;
    }
    public void DecrementarSeg(){
        if(seg == 0){
            seg = 59;
            if(min == 0){
                min = 59;
                if(hora == 0){
                    hora = 23;
                }
                else hora--;
            }else min--;
            
        }else seg--;
    }
    public int Comparar(int hora, int min, int seg){
        int res;
        if(this.hora > hora){
            return 1;
        }
        else if(this.hora == hora){
            if(this.min > min){
                return 1;
            }
            else if(this.min == min){
                if(this.seg > seg){
                    return 1;
                }
                else if(this.seg == seg){
                    return 0;
                }
                else {
                    return -1;
                }
            }
            else {
                return -1;
            }
        }
        else{
            return -1;
        }
    }
    public int Comparar(Hora h){
        return Comparar(h.hora, h.min, h.seg);
    }
    public boolean IgualQue(int hora, int min, int seg){
        int res = Comparar(hora, min, seg);
        if(res == 0){
            return true;
        }
        return false;
    }
    public boolean IgualQue(Hora h){
        return IgualQue(h.hora, h.min, h.seg);
    }
    public boolean MayorQue(int hora, int min, int seg){
        int res = Comparar(hora, min, seg);
        if(res == 1){
            return true;
        }
        return false;
    }
    public boolean MayorQue(Hora h){
        return MayorQue(h.hora, h.min, h.seg);
    }
    public boolean MenorQue(int hora, int min, int seg){
        int res = Comparar(hora, min, seg);
        if(res == -1){
            return true;
        }
        return false;
    }
    public boolean MenorQue(Hora h){
        return MenorQue(h.hora, h.min, h.seg);
    }
    public int SegundosDesde(Hora h){
        int seg;
        seg = this.TotalSegundos() + h.TotalSegundos();
        return seg;
    }
    public Hora Copia(){
        int hora = this.hora;
        int min = this.min;
        int seg = this.seg;
        return new Hora(hora, min, seg);
    }
    public String Imprimir(){
        return this.hora+": "+this.min+": "+this.seg;
    }
    public String Imprimir12h(){
        String c = "";
        int cont = 13;
        int aux = 1;
        if(this.hora < 12){
            c = this.hora+":"+this.min+":"+this.seg+"am";
        }
        else{
            if(this.hora == 12) c = this.hora+":"+this.min+":"+this.seg+"pm";
            else{
                while(cont<=23){
                    if(cont == this.hora){
                        this.hora = aux;
                        
                        break;
                        
                    }
                     aux++;
                   cont++;
                }
            }
        }
        return c;
    }
    
}
